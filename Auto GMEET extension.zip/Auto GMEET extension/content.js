Promise.all([
    settingsLoaded,
    windowLoaded,
]).then(async () => {
    const togglesObj = createToggles();
    const toggles = Object.values(togglesObj);
    await new Promise(resolve => {
        const observer = new MutationObserver(() => {
            if (!toggles.every(toggle => toggle.buttonEl = document.querySelector(`[role="button"][aria-label$=" + ${toggle.key})" i][data-is-muted]`)))
                return;
            observer.disconnect();
            resolve();
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });
    });
    const preMeetingToggles = toggles.filter((toggle) => {
        const isPreMeeting = toggle.buttonEl.tagName === 'DIV';
        if (isPreMeeting) {
            toggle.onChange((checkboxEl) => {
                if (checkboxEl.checked)
                    toggle.disable();
            });
            toggle.labelStyle = {
                color: 'white',
                position: 'absolute',
                bottom: '0',
                [toggle.direction]: '100px',
                zIndex: '1',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
            };
            toggle.checkboxStyle = {
                cursor: 'pointer',
                margin: '0 4px 0 0',
                position: 'relative',
                top: '1px',
            };
            toggle.buttonEl.parentElement.append(toggle.labelEl);
        }
        if (toggle.autoDisable)
            toggle.disable();
        return isPreMeeting;
    });
    if (preMeetingToggles.length)
        chrome.storage.sync.onChanged.addListener(changes => Object.entries(changes)
            .forEach(([storageName, { newValue }]) => togglesObj[storageName].checked = newValue));
        
    // Call the autoJoin function
    autoJoin();
});

// Define the autoJoin function
const autoJoin = () => {
    var initiateAutoJoin = setInterval(() => {
      try {
        var micButton = document.getElementsByClassName(
          'U26fgb JRY2Pb mUbCce kpROve yBiuPb y1zVCf HNeRed M9Bg4d'
        )[0];
        if (typeof micButton != 'undefined' && micButton != null) {
          micButton.click();
          console.log('Clicked mic button');
        }
      } catch (err) {
        console.log(err);
      }
      try {
        var camButton = document.getElementsByClassName(
          'U26fgb JRY2Pb mUbCce kpROve yBiuPb y1zVCf HNeRed M9Bg4d'
        )[0];
        if (typeof camButton != 'undefined' && camButton != null) {
          camButton.click();
          console.log('Clicked cam button');
        }
      } catch (err) {
        console.log(err);
      }
      try {
        var joinButton = document.getElementsByClassName(
          'VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-k8QpJ VfPpkd-LgbsSe-OWXEXe-dgl2Hf nCP5yc AjY5Oe DuMIQc LQeN7 jEvJdc QJgqC'
        )[0];
        if (typeof joinButton != 'undefined' && joinButton != null) {
          joinButton.click();
          console.log('Clicked join button');
        }
      } catch (err) {
        console.log(err);
      }
      try {
        var joinRecording = document.getElementsByClassName(
          'U26fgb O0WRkf oG5Srb HQ8yf C0oVfc kHssdc HvOprf M9Bg4d'
        )[0];
        if (typeof joinRecording != 'undefined' && joinRecording != null) {
          joinRecording.click();
          console.log('Clicked join now button when recording');
        }
      } catch (err) {
        console.log(err);
      }
      if (!micButton && !camButton && !joinButton && !joinRecording) {
        console.log('Joined the meeting!');
        console.log('Stopping Auto Join execution');
        clearInterval(initiateAutoJoin);
      }
    }, 10000);
  };
  